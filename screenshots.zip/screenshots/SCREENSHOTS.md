# Screenshoty webu petrslavik.cz

> Vygenerováno automaticky ze skriptu `screenshots.mjs`
> Zdroj: `http://localhost:3000`
> Datum: 29. 4. 2026

---

## Struktura složek

```
screenshots/
├── desktop/   full-page screenshoty v rozlišení 1440 × 900 px
├── mobile/    full-page screenshoty na iPhone 13 (390 × 844 px)
└── anim/      animační a hover stavy — snímky patřící k sobě jsou seskupeny níže
```

---

## Full-page screenshoty — Desktop & Mobile

| Soubor | Stránka |
|--------|---------|
| `desktop/01-home.png` + `mobile/01-home.png` | `/` |
| `desktop/02-sluzby.png` + `mobile/02-sluzby.png` | `/sluzby` |
| `desktop/03-sluzby-weby.png` + `mobile/03-sluzby-weby.png` | `/sluzby/webove-stranky` |
| `desktop/04-sluzby-eshop.png` + `mobile/04-sluzby-eshop.png` | `/sluzby/e-shop` |
| `desktop/05-sluzby-cms.png` + `mobile/05-sluzby-cms.png` | `/sluzby/webove-aplikace` |
| `desktop/06-cenik.png` + `mobile/06-cenik.png` | `/cenik` |
| `desktop/07-reference.png` + `mobile/07-reference.png` | `/reference` |
| `desktop/08-reference-detail.png` + `mobile/08-reference-detail.png` | `/reference/firemni-web` |
| `desktop/09-proces.png` + `mobile/09-proces.png` | `/proces` |
| `desktop/10-blog.png` + `mobile/10-blog.png` | `/blog` |
| `desktop/11-blog-detail.png` + `mobile/11-blog-detail.png` | `/blog/tvorba-webu-na-miru` |
| `desktop/12-integrace-pohoda.png` + `mobile/12-integrace-pohoda.png` | `/integrace/pohoda` |
| `desktop/13-platformy-shoptet.png` + `mobile/13-platformy-shoptet.png` | `/platformy/shoptet` |
| `desktop/14-platformy-upgates.png` + `mobile/14-platformy-upgates.png` | `/platformy/upgates` |
| `desktop/15-platformy-woo.png` + `mobile/15-platformy-woo.png` | `/platformy/woocommerce` |
| `desktop/16-o-mne.png` + `mobile/16-o-mne.png` | `/o-mne` |
| `desktop/17-kontakt.png` + `mobile/17-kontakt.png` | `/kontakt` |
| `desktop/18-gdpr.png` + `mobile/18-gdpr.png` | `/ochrana-osobnich-udaju` |
| `desktop/19-cookies.png` + `mobile/19-cookies.png` | `/cookies` |

---

## Animační a hover stavy (`anim/`)

> Snímky v každé skupině zachycují **jednu animaci nebo interakci** ve více fázích.
> Zobraz je vedle sebe nebo postupně za sebou, aby byl patrný vizuální efekt.

### Hero sekce — vstupní animace a spotlight

| Soubor | Popis |
|--------|-------|
| `anim/hero-01-default.png` | Hero — výchozí stav (nad záhybem) |
| `anim/hero-02-spotlight.png` | Hero — spotlight cursor efekt (myš nad textem) |

### Marquee — pohyblivý pásek služeb

| Soubor | Popis |
|--------|-------|
| `anim/marquee-01.png` | Marquee — snímek 1 (t=0) |
| `anim/marquee-02.png` | Marquee — snímek 2 (t+800ms) |
| `anim/marquee-03.png` | Marquee — snímek 3 (t+1600ms) |

### Navigace — hover na položkách menu

| Soubor | Popis |
|--------|-------|
| `anim/nav-01-default.png` | Navigace — výchozí stav |
| `anim/nav-02-hover.png` | Navigace — hover na položce Ceník |

### CTA tlačítko — výchozí vs. hover

| Soubor | Popis |
|--------|-------|
| `anim/cta-btn-01-default.png` | CTA tlačítko — výchozí stav |
| `anim/cta-btn-02-hover.png` | CTA tlačítko — hover stav (stín + posun) |

### Karty služeb — výchozí vs. hover

| Soubor | Popis |
|--------|-------|
| `anim/karta-01-default.png` | Karta služby — výchozí stav |
| `anim/karta-02-hover.png` | Karta služby — hover stav (posun + stín) |

### FAQ Accordion — zavřený vs. otevřený

| Soubor | Popis |
|--------|-------|
| `anim/faq-01-closed.png` | FAQ — všechny položky zavřené |
| `anim/faq-02-open.png` | FAQ — první položka otevřená |

### Footer CTA „DO TOHO!" — spotlight efekt

| Soubor | Popis |
|--------|-------|
| `anim/footer-cta-01-default.png` | Footer CTA "DO TOHO!" — výchozí |
| `anim/footer-cta-02-spotlight.png` | Footer CTA "DO TOHO!" — spotlight efekt |

### Ceník — karty výchozí vs. hover

| Soubor | Popis |
|--------|-------|
| `anim/cenik-karty-01-default.png` | Ceník — karty výchozí stav |
| `anim/cenik-karty-02-hover.png` | Ceník — hover na kartě (posun + stín) |

### Reference — karty výchozí vs. hover

| Soubor | Popis |
|--------|-------|
| `anim/reference-karta-01-default.png` | Reference — karta výchozí stav |
| `anim/reference-karta-02-hover.png` | Reference — hover (posun + stín) |

---

## Popis animací

| Animace | Kde na webu | Spouštěč | Technologie |
|---------|------------|----------|-------------|
| **Spotlight cursor** | Tmavé sekce (hero, footer CTA, Pro koho tvořím) | Pohyb myši | `useMotionValue` + rAF |
| **Marquee pásek** | Homepage pod hero | Automaticky, loop | CSS `@keyframes` translateX |
| **Fade-in při scrollu** | Všechny sekce a karty | `whileInView` | Framer Motion |
| **Card hover** | Karty služeb, ceník, reference | Hover myší | CSS transition + shadow |
| **Nav hover** | Hlavní navigace | Hover myší | CSS transition color |
| **Button hover** | CTA tlačítka | Hover myší | CSS transition + shadow |
| **FAQ accordion** | Sekce FAQ na homepage | Klik | State toggle + CSS transition |
| **Hero text fade** | Hero sekce | Načtení stránky | Framer Motion `initial → animate` |
